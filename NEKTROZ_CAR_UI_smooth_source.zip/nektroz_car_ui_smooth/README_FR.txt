NEKTROZ CAR UI — V2 SMOOTH / LOW-OVERHEAD

But :
- interface de launcher simple, paysage, sans widgets ;
- écran d'accueil : horloge, raccourci AutoLink, bouton « Toutes les apps », paramètres ;
- tiroir d'applications chargé seulement quand on l'ouvre ;
- icônes d'applications Android originales et recherche ;
- aucune permission réseau, aucun service permanent, aucun widget, aucune animation décorative ;
- aucune application n'est désinstallée ou désactivée ;
- AutoLink, Bluetooth, CAN, caméra et composants constructeur ne sont pas modifiés.

Optimisations dans le launcher :
- aucune tâche de fond permanente ;
- horloge actualisée une fois par minute seulement ;
- liste d'applications chargée à l'ouverture du tiroir ;
- défilement sans effets décoratifs superflus.

Limite essentielle :
Un launcher léger peut réduire le travail demandé à l'interface d'accueil, mais il ne peut pas à lui seul corriger les bugs d'AutoLink, les limites du processeur/RAM, la surchauffe, les défauts Wi-Fi/Bluetooth ou un firmware constructeur instable.
Ne pas utiliser de « RAM booster », task killer ou nettoyeur automatique : ils peuvent fermer des services AutoLink/Bluetooth et empirer les reconnexions.

APK :
Ce dossier est le CODE SOURCE, pas un APK compilé. Compiler avec Android Studio + Android SDK :
1. Ouvrir le dossier du projet dans Android Studio.
2. Synchroniser Gradle.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Installer et tester sans remplacer le launcher d'origine.
5. Vérifier AutoLink, Bluetooth, audio, commandes au volant et caméra.
6. Choisir le nouveau launcher par défaut uniquement si tout fonctionne.

Pour diagnostiquer les bugs du boîtier, il faudra ensuite distinguer :
- lenteur de l'interface d'accueil ;
- coupures/décrochages Apple CarPlay via AutoLink ;
- bugs audio/Bluetooth ;
- lenteurs de navigation/GPS ;
- redémarrages ou surchauffe.

Ne pas réinitialiser le MCU, CAN ou firmware sans procédure officielle du fabricant.
