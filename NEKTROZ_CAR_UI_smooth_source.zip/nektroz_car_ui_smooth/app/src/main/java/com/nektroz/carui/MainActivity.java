package com.nektroz.carui;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 15, 19);
    private static final int PANEL = Color.rgb(24, 29, 35);
    private static final int PANEL_HI = Color.rgb(34, 41, 48);
    private static final int WHITE = Color.rgb(244, 247, 249);
    private static final int MUTED = Color.rgb(143, 153, 162);
    private static final int ACCENT = Color.rgb(164, 222, 205);
    private PackageManager pm;
    private List<ResolveInfo> allApps = new ArrayList<>();
    private ResolveInfo autoLink;
    private LinearLayout page;
    private TextView clock, date;
    private EditText search;
    private LinearLayout appRows;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        pm = getPackageManager();
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        loadApps();
        showHome();
        tick();
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, float size, int color, boolean medium) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.create(medium ? "sans-serif-medium" : "sans-serif", Typeface.NORMAL));
        return t;
    }
    private void loadApps() {
        Intent q = new Intent(Intent.ACTION_MAIN, null);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        allApps = pm.queryIntentActivities(q, 0);
        Collections.sort(allApps, (a,b) -> String.CASE_INSENSITIVE_ORDER.compare(
            a.loadLabel(pm).toString(), b.loadLabel(pm).toString()));
        for (ResolveInfo r : allApps) {
            String n = r.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            if (n.contains("autolink") || n.contains("auto link")) { autoLink = r; break; }
        }
    }
    private void launch(ResolveInfo r) {
        if (r == null) return;
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        i.setClassName(r.activityInfo.packageName, r.activityInfo.name);
        try { startActivity(i); }
        catch (Exception e) { Toast.makeText(this, "Impossible d'ouvrir cette application", Toast.LENGTH_SHORT).show(); }
    }
    private void launchAutoLink() {
        if (autoLink == null) {
            Toast.makeText(this, "AutoLink n'a pas été détecté. Il reste installé : ouvre-le depuis Toutes les applications.", Toast.LENGTH_LONG).show();
        } else launch(autoLink);
    }
    private void basePage() {
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(30,20,30,18);
        page.setBackgroundColor(BG);
        page.setClipToPadding(true);
        page.setClipChildren(true);
        setContentView(page);
    }
    private void showHome() {
        basePage();
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = text("N", 17, BG, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(rounded(ACCENT, 13));
        top.addView(logo, new LinearLayout.LayoutParams(36,36));
        TextView brand = text("  NEKTROZ", 15, WHITE, true);
        top.addView(brand);
        View gap = new View(this);
        top.addView(gap,new LinearLayout.LayoutParams(0,1,1));
        TextView all = text("TOUTES LES APPS   ⠿", 10, ACCENT, true);
        all.setPadding(15,12,15,12);
        all.setBackground(rounded(PANEL,16));
        all.setOnClickListener(v -> showDrawer(""));
        top.addView(all);
        page.addView(top);

        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        page.addView(center,new LinearLayout.LayoutParams(-1,0,1));

        clock = text("--:--", 66, WHITE, false);
        clock.setGravity(Gravity.CENTER);
        center.addView(clock);
        date = text("", 10, MUTED, true);
        date.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1,-2);
        dlp.topMargin=8; dlp.bottomMargin=28;
        center.addView(date,dlp);

        LinearLayout hero = new LinearLayout(this);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        hero.setPadding(22,18,22,18);
        hero.setBackground(rounded(PANEL,24));
        FrameLayout iconFrame = new FrameLayout(this);
        iconFrame.setBackground(rounded(PANEL_HI,18));
        ImageView autoIcon = new ImageView(this);
        if (autoLink != null) {
            try { autoIcon.setImageDrawable(autoLink.loadIcon(pm)); } catch(Exception ignored) {}
        }
        if (autoLink != null) {
            autoIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(44,44,Gravity.CENTER);
            iconFrame.addView(autoIcon,ip);
        } else {
            TextView a = text("A",24,ACCENT,true); a.setGravity(Gravity.CENTER);
            iconFrame.addView(a,new FrameLayout.LayoutParams(62,62));
        }
        hero.addView(iconFrame,new LinearLayout.LayoutParams(62,62));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setPadding(16,0,0,0);
        TextView title = text("Apple CarPlay",18,WHITE,true);
        TextView subtitle = text("Ouvrir AutoLink",11,MUTED,false);
        copy.addView(title);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-2,-2);
        sl.topMargin=5; copy.addView(subtitle,sl);
        hero.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow = text("↗",23,ACCENT,false); arrow.setGravity(Gravity.CENTER);
        hero.addView(arrow,new LinearLayout.LayoutParams(35,48));
        hero.setOnClickListener(v -> launchAutoLink());
        center.addView(hero,new LinearLayout.LayoutParams(-1,100));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        TextView note = text("VOTRE ESPACE DE CONDUITE",9,MUTED,true);
        bottom.addView(note,new LinearLayout.LayoutParams(0,-2,1));
        TextView settings = text("⚙",19,WHITE,false);
        settings.setGravity(Gravity.CENTER);
        settings.setBackground(rounded(PANEL,15));
        bottom.addView(settings,new LinearLayout.LayoutParams(46,42));
        settings.setOnClickListener(v -> startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)));
        page.addView(bottom);
    }
    private void showDrawer(String filter) {
        basePage();
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹",32,WHITE,false);
        back.setGravity(Gravity.CENTER);
        top.addView(back,new LinearLayout.LayoutParams(42,48));
        back.setOnClickListener(v -> showHome());
        TextView heading = text("Applications",23,WHITE,true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0,-2,1);
        hp.leftMargin=8; top.addView(heading,hp);
        TextView count = text(String.valueOf(allApps.size()),11,ACCENT,true);
        top.addView(count);
        page.addView(top);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(WHITE);
        search.setHintTextColor(MUTED);
        search.setHint("Rechercher une application");
        search.setTextSize(14);
        search.setPadding(16,0,16,0);
        search.setBackground(rounded(PANEL,16));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1,50);
        slp.topMargin=14; slp.bottomMargin=12; page.addView(search,slp);

        ScrollView scroll = new ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        appRows = new LinearLayout(this);
        appRows.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(appRows);
        page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        renderApps(filter);
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            public void onTextChanged(CharSequence s,int st,int before,int count) { renderApps(s.toString()); }
            public void afterTextChanged(Editable e) {}
        });
    }
    private void renderApps(String filter) {
        if (appRows == null) return;
        appRows.removeAllViews();
        String f = filter == null ? "" : filter.toLowerCase(Locale.ROOT).trim();
        int shown = 0;
        LinearLayout row = null;
        for (ResolveInfo r : allApps) {
            String name = r.loadLabel(pm).toString();
            if (!name.toLowerCase(Locale.ROOT).contains(f)) continue;
            if (shown % 4 == 0) {
                row = new LinearLayout(this);
                row.setGravity(Gravity.TOP);
                appRows.addView(row,new LinearLayout.LayoutParams(-1,-2));
            }
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(5,12,5,10);
            ImageView icon = new ImageView(this);
            icon.setLayerType(View.LAYER_TYPE_NONE, null);
            try { icon.setImageDrawable(r.loadIcon(pm)); } catch(Exception ignored) {}
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            tile.addView(icon,new LinearLayout.LayoutParams(42,42));
            TextView label = text(name,10,WHITE,true);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,34);
            lp.topMargin=7; tile.addView(label,lp);
            tile.setOnClickListener(v -> launch(r));
            LinearLayout.LayoutParams cell = new LinearLayout.LayoutParams(0,105,1);
            cell.setMargins(3,3,3,3);
            row.addView(tile,cell);
            shown++;
        }
        if (shown == 0) {
            TextView empty = text("Aucune application trouvée",13,MUTED,false);
            empty.setPadding(8,20,8,20); appRows.addView(empty);
        }
    }
    private void tick() {
        if (clock != null) {
            Date now = new Date();
            clock.setText(new SimpleDateFormat("HH:mm",Locale.getDefault()).format(now));
            date.setText(new SimpleDateFormat("EEEE  ·  d MMMM",Locale.getDefault()).format(now).toUpperCase(Locale.getDefault()));
            clock.postDelayed(this::tick,60000);
        }
    }
}
